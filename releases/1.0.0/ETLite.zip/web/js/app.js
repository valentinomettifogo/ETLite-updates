// Tab navigation
document.querySelectorAll('.sidebar .nav-link').forEach(link => {
    link.addEventListener('click', function(e) {
        e.preventDefault();
        
        // Remove active class from all links and tabs
        document.querySelectorAll('.sidebar .nav-link').forEach(l => l.classList.remove('active'));
        document.querySelectorAll('.tab-content').forEach(t => t.classList.remove('active'));
        
        // Add active class to clicked link
        this.classList.add('active');
        
        // Show corresponding tab
        const tabId = this.getAttribute('data-tab') + '-tab';
        document.getElementById(tabId).classList.add('active');
        
        // Load content based on tab
        const tab = this.getAttribute('data-tab');
        if (tab === 'settings') {
            loadConfig();
        } else if (tab === 'sql-list') {
            loadSQLFiles();
        } else if (tab === 'variables') {
            loadVariables();
        } else if (tab === 'qlik-cloud') {
            loadConfig();  // Carica anche i dati Qlik
        } else if (tab === 'info') {
            loadVersions();
        } else if (tab === 'log') {
            loadLogs();
        }
    });
});

// Load SQL files
async function loadSQLFiles() {
    const tbody = document.getElementById('sqlFilesBody');
    tbody.innerHTML = '<tr><td colspan="3" class="text-center"><i class="bi bi-hourglass-split"></i> Loading...</td></tr>';
    
    try {
        const response = await fetch('/api/sql-files');
        if (!response.ok) throw new Error('Failed to load SQL files');
        
        const files = await response.json();
        
        if (files.length === 0) {
            tbody.innerHTML = '<tr><td colspan="3" class="text-center text-muted">No SQL files found in etl/ directory</td></tr>';
            return;
        }
        
        tbody.innerHTML = files.map(file => `
            <tr id="row-${file.name}">
                <td><i class="bi bi-file-earmark-code text-primary"></i> ${file.name}</td>
                <td><span class="badge bg-secondary" id="status-${file.name}">Ready</span></td>
                <td>
                    <button class="btn btn-sm btn-primary" onclick="extractTable('${file.name}')">
                        <i class="bi bi-play-fill"></i> Extract
                    </button>
                </td>
            </tr>
        `).join('');
    } catch (error) {
        tbody.innerHTML = `<tr><td colspan="3" class="text-center text-danger">Error: ${error.message}</td></tr>`;
    }
}

// Extract table
async function extractTable(tableName) {
    const statusBadge = document.getElementById(`status-${tableName}`);
    const row = document.getElementById(`row-${tableName}`);
    const button = row.querySelector('button');
    
    // Update UI
    statusBadge.className = 'badge bg-warning';
    statusBadge.innerHTML = '<i class="bi bi-hourglass-split"></i> Extracting...';
    button.disabled = true;
    
    try {
        const response = await fetch('/api/extract', {
            method: 'POST',
            headers: {
                'Content-Type': 'application/json'
            },
            body: JSON.stringify({ table_name: tableName })
        });
        
        const result = await response.json();
        
        if (result.status === 'success') {
            statusBadge.className = 'badge bg-success';
            statusBadge.innerHTML = '<i class="bi bi-check-circle-fill"></i> Completed';
            setTimeout(() => {
                statusBadge.className = 'badge bg-secondary';
                statusBadge.textContent = 'Ready';
                button.disabled = false;
            }, 3000);
        } else {
            statusBadge.className = 'badge bg-danger';
            statusBadge.innerHTML = '<i class="bi bi-x-circle-fill"></i> Failed';
            // Show detailed error with output
            const errorMsg = result.message + (result.output ? '\n\nOutput:\n' + result.output : '');
            showErrorModal(errorMsg);
            button.disabled = false;
        }
    } catch (error) {
        statusBadge.className = 'badge bg-danger';
        statusBadge.innerHTML = '<i class="bi bi-x-circle-fill"></i> Error';
        showErrorModal('Connection error: ' + error.message);
        button.disabled = false;
    }
}

// Extract all tables
async function extractAll() {
    const tbody = document.getElementById('sqlFilesBody');
    const rows = tbody.querySelectorAll('tr[id^="row-"]');
    
    if (rows.length === 0) {
        showErrorModal('No SQL files found to extract');
        return;
    }
    
    // Disable Extract All button
    const extractAllBtn = event.target.closest('button');
    extractAllBtn.disabled = true;
    extractAllBtn.innerHTML = '<i class="bi bi-hourglass-split"></i> Extracting All...';
    
    // Set all tables to "extracting" status
    for (const row of rows) {
        const tableName = row.id.replace('row-', '');
        const statusBadge = document.getElementById(`status-${tableName}`);
        const button = row.querySelector('button');
        
        statusBadge.className = 'badge bg-warning';
        statusBadge.innerHTML = '<i class="bi bi-hourglass-split"></i> Extracting...';
        button.disabled = true;
    }
    
    try {
        // Call extract-all API (single task for all tables)
        const response = await fetch('/api/extract-all', {
            method: 'POST',
            headers: {
                'Content-Type': 'application/json'
            }
        });
        
        const result = await response.json();
        
        // Update all statuses based on result
        for (const row of rows) {
            const tableName = row.id.replace('row-', '');
            const statusBadge = document.getElementById(`status-${tableName}`);
            const button = row.querySelector('button');
            
            if (result.status === 'success') {
                statusBadge.className = 'badge bg-success';
                statusBadge.innerHTML = '<i class="bi bi-check-circle-fill"></i> Completed';
            } else {
                statusBadge.className = 'badge bg-danger';
                statusBadge.innerHTML = '<i class="bi bi-x-circle-fill"></i> Failed';
            }
            button.disabled = false;
        }
        
        if (result.status !== 'success') {
            showErrorModal('Extraction failed: ' + result.message);
        }
    } catch (error) {
        // Mark all as error
        for (const row of rows) {
            const tableName = row.id.replace('row-', '');
            const statusBadge = document.getElementById(`status-${tableName}`);
            const button = row.querySelector('button');
            
            statusBadge.className = 'badge bg-danger';
            statusBadge.innerHTML = '<i class="bi bi-x-circle-fill"></i> Error';
            button.disabled = false;
        }
        showErrorModal('Connection error: ' + error.message);
    }
    
    // Re-enable Extract All button
    extractAllBtn.disabled = false;
    extractAllBtn.innerHTML = '<i class="bi bi-play-fill"></i> Extract All';
    
    // Reload logs to show all extraction events
    loadLogs();
}

// Extract all tables WITH Qlik automation
async function extractAllWithQlik() {
    const rows = document.querySelectorAll('#sqlFilesBody tr');
    if (rows.length === 0) return;
    
    // Get button reference
    const extractAllBtn = event.target.closest('button');
    extractAllBtn.disabled = true;
    extractAllBtn.innerHTML = '<i class="bi bi-hourglass-split"></i> Extracting All + Qlik...';
    
    // Set all tables to "extracting" status
    for (const row of rows) {
        const tableName = row.id.replace('row-', '');
        const statusBadge = document.getElementById(`status-${tableName}`);
        const button = row.querySelector('button');
        
        statusBadge.className = 'badge bg-warning';
        statusBadge.innerHTML = '<i class="bi bi-hourglass-split"></i> Extracting...';
        button.disabled = true;
    }
    
    try {
        // Call extract-all API with Qlik flag
        const response = await fetch('/api/extract-all-qlik', {
            method: 'POST',
            headers: {
                'Content-Type': 'application/json'
            }
        });
        
        const result = await response.json();
        
        // Update all statuses based on result
        for (const row of rows) {
            const tableName = row.id.replace('row-', '');
            const statusBadge = document.getElementById(`status-${tableName}`);
            const button = row.querySelector('button');
            
            if (result.status === 'success') {
                statusBadge.className = 'badge bg-success';
                statusBadge.innerHTML = '<i class="bi bi-check-circle-fill"></i> Completed';
            } else {
                statusBadge.className = 'badge bg-danger';
                statusBadge.innerHTML = '<i class="bi bi-x-circle-fill"></i> Failed';
            }
            button.disabled = false;
        }
        
        if (result.status !== 'success') {
            showErrorModal('Extraction failed: ' + result.message);
        }
    } catch (error) {
        // Mark all as error
        for (const row of rows) {
            const tableName = row.id.replace('row-', '');
            const statusBadge = document.getElementById(`status-${tableName}`);
            const button = row.querySelector('button');
            
            statusBadge.className = 'badge bg-danger';
            statusBadge.innerHTML = '<i class="bi bi-x-circle-fill"></i> Error';
            button.disabled = false;
        }
        showErrorModal('Connection error: ' + error.message);
    }
    
    // Re-enable Extract All button
    extractAllBtn.disabled = false;
    extractAllBtn.innerHTML = '<i class="bi bi-cloud-upload"></i> Extract All + Qlik';
    
    // Reload logs to show all extraction events
    loadLogs();
}

// Load config on settings tab
async function loadConfig() {
    try {
        const response = await fetch('/api/config');
        if (response.ok) {
            const config = await response.json();
            document.getElementById('dnsName').value = config.dns_name || '';
            document.getElementById('user').value = config.user || '';
            document.getElementById('password').value = config.password || '';
            document.getElementById('library').value = config.library || '';
            document.getElementById('etlPath').value = config.etl_path || 'etl';
            document.getElementById('storePath').value = config.store_path || 'store';
            document.getElementById('outputFormat').value = config.output_format || 'parquet';
            document.getElementById('qlikAutomation').checked = config.qlik_automation || false;
            document.getElementById('qlikUrl').value = config.qlik_url || '';
            document.getElementById('qlikToken').value = config.qlik_token || '';
        }
    } catch (error) {
        console.error('Error loading config:', error);
    }
}

// Handle form submission
document.getElementById('configForm').addEventListener('submit', async (e) => {
    e.preventDefault();
    
    const formData = {
        dns_name: document.getElementById('dnsName').value,
        user: document.getElementById('user').value,
        password: document.getElementById('password').value,
        library: document.getElementById('library').value,
        etl_path: document.getElementById('etlPath').value,
        store_path: document.getElementById('storePath').value,
        output_format: document.getElementById('outputFormat').value
    };

    try {
        const response = await fetch('/api/config', {
            method: 'POST',
            headers: {
                'Content-Type': 'application/json'
            },
            body: JSON.stringify(formData)
        });

        const result = await response.json();

        if (response.ok) {
            showSuccessModal();
        } else {
            showErrorModal('Error saving configuration');
        }
    } catch (error) {
        showErrorModal('Server connection error');
    }
});

function showSuccessModal() {
    const modal = new bootstrap.Modal(document.getElementById('successModal'));
    modal.show();
}

function showErrorModal(message) {
    document.getElementById('errorMessage').textContent = message;
    const modal = new bootstrap.Modal(document.getElementById('errorModal'));
    modal.show();
}

// Variables management
async function loadVariables() {
    const tbody = document.getElementById('variablesBody');
    tbody.innerHTML = '<tr><td colspan="3" class="text-center"><i class="bi bi-hourglass-split"></i> Loading...</td></tr>';
    
    try {
        const response = await fetch('/api/variables');
        if (!response.ok) throw new Error('Failed to load variables');
        
        const variables = await response.json();
        
        if (!variables || variables.length === 0) {
            tbody.innerHTML = '<tr><td colspan="3" class="text-center text-muted">No variables defined. Click "Add Variable" to create one.</td></tr>';
            return;
        }
        
        tbody.innerHTML = variables.map(v => `
            <tr>
                <td><code>\$(${v.name})</code></td>
                <td>${v.value}</td>
                <td>
                    <button class="btn btn-sm btn-outline-primary me-2" onclick="editVariable('${v.name}', '${v.value}')">
                        <i class="bi bi-pencil"></i> Edit
                    </button>
                    <button class="btn btn-sm btn-outline-danger" onclick="deleteVariable('${v.name}')">
                        <i class="bi bi-trash"></i> Delete
                    </button>
                </td>
            </tr>
        `).join('');
    } catch (error) {
        tbody.innerHTML = `<tr><td colspan="3" class="text-center text-danger">Error: ${error.message}</td></tr>`;
    }
}

function editVariable(name, value) {
    document.getElementById('variableName').value = name;
    document.getElementById('variableValue').value = value;
    document.getElementById('variableName').readOnly = true;
    const modal = new bootstrap.Modal(document.getElementById('addVariableModal'));
    modal.show();
}

// Reset form when modal closes
document.getElementById('addVariableModal').addEventListener('hidden.bs.modal', function () {
    document.getElementById('variableForm').reset();
    document.getElementById('variableName').readOnly = false;
});

async function saveVariable() {
    const name = document.getElementById('variableName').value.trim();
    const value = document.getElementById('variableValue').value.trim();
    
    if (!name || !value) {
        showErrorModal('Name and value are required');
        return;
    }
    
    try {
        const response = await fetch('/api/variables', {
            method: 'POST',
            headers: {
                'Content-Type': 'application/json'
            },
            body: JSON.stringify({ name, value })
        });
        
        if (!response.ok) throw new Error('Failed to save variable');
        
        // Close modal and reload
        bootstrap.Modal.getInstance(document.getElementById('addVariableModal')).hide();
        loadVariables();
        showSuccessModal();
    } catch (error) {
        showErrorModal('Error saving variable: ' + error.message);
    }
}

async function deleteVariable(name) {
    if (!confirm(`Are you sure you want to delete variable $(${name})?`)) {
        return;
    }
    
    try {
        const response = await fetch('/api/variables/delete', {
            method: 'POST',
            headers: {
                'Content-Type': 'application/json'
            },
            body: JSON.stringify({ name })
        });
        
        if (!response.ok) throw new Error('Failed to delete variable');
        
        loadVariables();
    } catch (error) {
        showErrorModal('Error deleting variable: ' + error.message);
    }
}

// Load versions
async function loadVersions() {
    const tbody = document.getElementById('versionsBody');
    tbody.innerHTML = '<tr><td colspan="4" class="text-center"><i class="bi bi-hourglass-split"></i> Loading...</td></tr>';
    
    try {
        const response = await fetch('/api/versions');
        if (!response.ok) throw new Error('Failed to load versions');
        
        const versions = await response.json();
        
        if (versions.length === 0) {
            tbody.innerHTML = '<tr><td colspan="4" class="text-center text-muted">No version history found</td></tr>';
            return;
        }
        
        tbody.innerHTML = versions.map(v => {
            let statusBadge = '';
            if (v.update_available) {
                statusBadge = `
                    <a href="${v.download_url}" target="_blank" class="badge bg-warning text-dark text-decoration-none" title="Click to download update">
                        <i class="bi bi-download"></i> ${v.latest_version} available
                    </a>
                `;
            } else {
                statusBadge = '<span class="badge bg-success"><i class="bi bi-check-circle"></i> Up to date</span>';
            }
            
            return `
                <tr>
                    <td><i class="bi bi-box-seam"></i> ${v.app_name}</td>
                    <td><span class="badge bg-primary">${v.version}</span></td>
                    <td>${statusBadge}</td>
                    <td>${v.updated_at}</td>
                </tr>
            `;
        }).join('');
    } catch (error) {
        tbody.innerHTML = `<tr><td colspan="4" class="text-center text-danger">Error: ${error.message}</td></tr>`;
    }
}

// Refresh versions - esegue tutti gli applicativi con --version e aggiorna il DB
async function refreshVersions() {
    const btn = event.target.closest('button');
    btn.disabled = true;
    btn.innerHTML = '<i class="bi bi-hourglass-split"></i> Refreshing...';
    
    try {
        const response = await fetch('/api/versions/refresh', {
            method: 'POST'
        });
        
        if (!response.ok) throw new Error('Failed to refresh versions');
        
        // Ricarica la tabella
        await loadVersions();
        
        btn.innerHTML = '<i class="bi bi-arrow-clockwise"></i> Refresh Versions';
    } catch (error) {
        showErrorModal('Error refreshing versions: ' + error.message);
        btn.innerHTML = '<i class="bi bi-arrow-clockwise"></i> Refresh Versions';
    } finally {
        btn.disabled = false;
    }
}

// Load logs
async function loadLogs() {
    const tbody = document.getElementById('logsBody');
    tbody.innerHTML = '<tr><td colspan="6" class="text-center"><i class="bi bi-hourglass-split"></i> Loading...</td></tr>';
    
    try {
        const response = await fetch('/api/logs');
        if (!response.ok) throw new Error('Failed to load logs');
        
        const logs = await response.json();
        
        if (logs.length === 0) {
            tbody.innerHTML = '<tr><td colspan="6" class="text-center text-muted">No logs available</td></tr>';
            return;
        }
        
        // Create a map of task_id to group index for alternating colors
        const taskGroups = {};
        let groupIndex = 0;
        logs.forEach(log => {
            if (!(log.task_id in taskGroups)) {
                taskGroups[log.task_id] = groupIndex % 2;
                groupIndex++;
            }
        });
        
        tbody.innerHTML = logs.map(log => {
            // Determina il badge per event_type
            let eventTypeBadge = '';
            if (log.event_type === 'info') {
                eventTypeBadge = '<span class="badge bg-info">Info</span>';
            } else if (log.event_type === 'extract_table') {
                eventTypeBadge = '<span class="badge bg-primary">Extract</span>';
            } else {
                eventTypeBadge = `<span class="badge bg-secondary">${log.event_type}</span>`;
            }
            
            // Determina il colore per result
            let resultClass = '';
            let resultIcon = '';
            if (log.result.includes('error')) {
                resultClass = 'text-danger';
                resultIcon = '<i class="bi bi-x-circle-fill"></i> ';
            } else if (log.result.includes('rows')) {
                resultClass = 'text-success';
                resultIcon = '<i class="bi bi-check-circle-fill"></i> ';
            } else if (log.result === 'completed') {
                resultClass = 'text-success';
                resultIcon = '<i class="bi bi-check-circle-fill"></i> ';
            }
            
            // Alternating row color based on task_id
            const rowClass = `log-task-group-${taskGroups[log.task_id]}`;
            
            // Format timestamp: from "2025-12-09T12:07:13Z" to "2025-12-09 12:07:13"
            const formattedTimestamp = log.timestamp.replace('T', ' ').replace('Z', '');
            
            return `
                <tr class="${rowClass}">
                    <td><code class="text-muted">${log.id}</code></td>
                    <td><code>${log.task_id}</code></td>
                    <td><small>${formattedTimestamp}</small></td>
                    <td>${eventTypeBadge}</td>
                    <td>${log.event}</td>
                    <td class="${resultClass}">${resultIcon}${log.result || '-'}</td>
                </tr>
            `;
        }).join('');
    } catch (error) {
        tbody.innerHTML = `<tr><td colspan="6" class="text-center text-danger">Error: ${error.message}</td></tr>`;
    }
}

// Handle Qlik form submission
document.getElementById('qlikForm').addEventListener('submit', async (e) => {
    e.preventDefault();
    
    // Get current config first
    try {
        const getResponse = await fetch('/api/config');
        if (!getResponse.ok) throw new Error('Failed to load config');
        const currentConfig = await getResponse.json();
        
        // Update with Qlik fields
        const formData = {
            ...currentConfig,
            qlik_automation: document.getElementById('qlikAutomation').checked,
            qlik_url: document.getElementById('qlikUrl').value,
            qlik_token: document.getElementById('qlikToken').value
        };
        
        const response = await fetch('/api/config', {
            method: 'POST',
            headers: {
                'Content-Type': 'application/json'
            },
            body: JSON.stringify(formData)
        });

        const result = await response.json();

        if (response.ok) {
            showSuccessModal();
        } else {
            showErrorModal('Error saving Qlik configuration');
        }
    } catch (error) {
        showErrorModal('Server connection error: ' + error.message);
    }
});
